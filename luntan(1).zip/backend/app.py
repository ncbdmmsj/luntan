from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import bcrypt
import os
from datetime import datetime
import base64

app = Flask(__name__)
CORS(app)

# 配置SQLite数据库
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///forum.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your-secret-key-here'

db = SQLAlchemy(app)

# 用户模型
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    avatar = db.Column(db.Text)  # Base64编码的头像
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    posts = db.relationship('Post', backref='author', lazy=True)
    comments = db.relationship('Comment', backref='author', lazy=True)

# 帖子模型
class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    comments = db.relationship('Comment', backref='post', lazy=True, cascade='all, delete-orphan')

# 评论模型
class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# 简单的头像处理函数
def process_avatar(image_data):
    # 简单的验证，确保是有效的Base64数据
    if image_data and image_data.startswith('data:image/'):
        return image_data
    return None

# 统一时间序列化函数，确保前后端时间一致
def format_datetime(dt):
    if dt is None:
        return None
    return dt.replace(microsecond=0).isoformat() + 'Z'

# 用户注册
@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()

    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': '用户名已存在'}), 400

    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': '邮箱已存在'}), 400

    # 使用bcrypt加密密码
    password_hash = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    # 处理头像
    avatar = None
    if data.get('avatar'):
        avatar = process_avatar(data['avatar'])

    user = User(
        username=data['username'],
        email=data['email'],
        password_hash=password_hash,
        avatar=avatar
    )

    db.session.add(user)
    db.session.commit()

    return jsonify({'message': '注册成功', 'user_id': user.id}), 201

# 用户登录
@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()

    user = User.query.filter_by(username=data['username']).first()

    if not user or not bcrypt.checkpw(data['password'].encode('utf-8'), user.password_hash.encode('utf-8')):
        return jsonify({'error': '用户名或密码错误'}), 401

    user_data = {
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'avatar': user.avatar
    }

    return jsonify({'message': '登录成功', 'user': user_data}), 200

# 获取帖子列表
@app.route('/api/posts', methods=['GET'])
def get_posts():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)

    posts = Post.query.order_by(Post.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    posts_data = []
    for post in posts.items:
        posts_data.append({
            'id': post.id,
            'title': post.title,
            'content': post.content[:200] + '...' if len(post.content) > 200 else post.content,
            'author': {
                'id': post.author.id,
                'username': post.author.username,
                'avatar': post.author.avatar
            },
            'created_at': format_datetime(post.created_at),
            'comment_count': len(post.comments)
        })

    return jsonify({
        'posts': posts_data,
        'total': posts.total,
        'pages': posts.pages,
        'current_page': page
    })

# 获取单个帖子详情
@app.route('/api/posts/<int:post_id>', methods=['GET'])
def get_post(post_id):
    post = Post.query.get_or_404(post_id)

    post_data = {
        'id': post.id,
        'title': post.title,
        'content': post.content,
        'author': {
            'id': post.author.id,
            'username': post.author.username,
            'avatar': post.author.avatar
        },
        'created_at': format_datetime(post.created_at),
        'updated_at': format_datetime(post.updated_at),
        'comments': []
    }

    # 获取评论，按创建时间正序排列（最早的在前）
    comments = Comment.query.filter_by(post_id=post_id).order_by(Comment.created_at.asc()).all()
    for comment in comments:
        post_data['comments'].append({
            'id': comment.id,
            'content': comment.content,
            'author': {
                'id': comment.author.id,
                'username': comment.author.username,
                'avatar': comment.author.avatar
            },
            'created_at': format_datetime(comment.created_at)
        })

    return jsonify(post_data)

# 发布帖子
@app.route('/api/posts', methods=['POST'])
def create_post():
    data = request.get_json()

    # 在实际应用中，这里应该验证用户身份
    user_id = data.get('user_id', 1)  # 临时使用，实际应该从session或token获取

    post = Post(
        title=data['title'],
        content=data['content'],
        user_id=user_id
    )

    db.session.add(post)
    db.session.commit()

    return jsonify({'message': '帖子发布成功', 'post_id': post.id}), 201

# 发布评论
@app.route('/api/posts/<int:post_id>/comments', methods=['POST'])
def create_comment(post_id):
    data = request.get_json()

    # 验证帖子存在
    post = Post.query.get_or_404(post_id)

    # 在实际应用中，这里应该验证用户身份
    user_id = data.get('user_id', 1)  # 临时使用，实际应该从session或token获取

    comment = Comment(
        content=data['content'],
        user_id=user_id,
        post_id=post_id
    )

    db.session.add(comment)
    db.session.commit()

    return jsonify({
        'message': '评论发布成功',
        'comment': {
            'id': comment.id,
            'content': comment.content,
            'author': {
                'id': comment.author.id,
                'username': comment.author.username,
                'avatar': comment.author.avatar
            },
            'created_at': format_datetime(comment.created_at)
        }
    }), 201

# 初始化数据库
@app.route('/api/init', methods=['POST'])
def init_db():
    db.create_all()
    return jsonify({'message': '数据库初始化成功'}), 200

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
