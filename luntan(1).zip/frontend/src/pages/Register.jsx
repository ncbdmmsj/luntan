import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Form, Input, Button, Card, message, Space, Upload } from 'antd';
import { UserOutlined, MailOutlined, LockOutlined, UserAddOutlined, UploadOutlined } from '@ant-design/icons';
import { authAPI } from '../utils/api';

const Register = () => {
  const [loading, setLoading] = useState(false);
  const [avatar, setAvatar] = useState('');
  const navigate = useNavigate();

  const beforeUpload = (file) => {
    const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
    if (!isJpgOrPng) {
      message.error('只能上传 JPG/PNG 格式的图片!');
      return false;
    }

    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('图片大小不能超过 2MB!');
      return false;
    }

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      setAvatar(reader.result);
    };

    return false;
  };

  const onFinish = async (values) => {
    setLoading(true);
    try {
      const userData = {
        ...values,
        avatar: avatar
      };

      await authAPI.register(userData);
      message.success('注册成功，请登录！');
      // 清除可能存在的旧登录状态，确保必须重新登录
      localStorage.removeItem('forumUser');
      navigate('/login', { replace: true });
    } catch (error) {
      message.error(error.error || '注册失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-form">
      <Card>
        <div className="form-title">
          <h2><UserAddOutlined /> 用户注册</h2>
        </div>

        <Form
          name="register"
          onFinish={onFinish}
          autoComplete="off"
          layout="vertical"
        >
          <div className="avatar-upload">
            {avatar ? (
              <img src={avatar} alt="头像预览" className="avatar-preview" />
            ) : (
              <div className="avatar-preview" style={{
                background: '#f0f0f0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '2rem',
                color: '#999'
              }}>
                <UserOutlined />
              </div>
            )}
            <Upload
              beforeUpload={beforeUpload}
              showUploadList={false}
              accept="image/jpeg,image/png"
            >
              <Button icon={<UploadOutlined />} size="small">
                上传头像
              </Button>
            </Upload>
          </div>

          <Form.Item
            label="用户名"
            name="username"
            rules={[
              { required: true, message: '请输入用户名!' },
              { min: 3, message: '用户名至少3个字符!' },
              { max: 20, message: '用户名不能超过20个字符!' },
              { pattern: /^[a-zA-Z0-9_]+$/, message: '用户名只能包含字母、数字和下划线!' }
            ]}
          >
            <Input
              prefix={<UserOutlined />}
              placeholder="请输入用户名"
              size="large"
            />
          </Form.Item>

          <Form.Item
            label="邮箱"
            name="email"
            rules={[
              { required: true, message: '请输入邮箱!' },
              { type: 'email', message: '请输入有效的邮箱地址!' }
            ]}
          >
            <Input
              prefix={<MailOutlined />}
              placeholder="请输入邮箱"
              size="large"
            />
          </Form.Item>

          <Form.Item
            label="密码"
            name="password"
            rules={[
              { required: true, message: '请输入密码!' },
              { min: 6, message: '密码至少6个字符!' }
            ]}
          >
            <Input.Password
              prefix={<LockOutlined />}
              placeholder="请输入密码"
              size="large"
            />
          </Form.Item>

          <Form.Item
            label="确认密码"
            name="confirmPassword"
            dependencies={['password']}
            rules={[
              { required: true, message: '请确认密码!' },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue('password') === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(new Error('两次输入的密码不一致!'));
                },
              }),
            ]}
          >
            <Input.Password
              prefix={<LockOutlined />}
              placeholder="请再次输入密码"
              size="large"
            />
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              loading={loading}
              size="large"
              block
            >
              注册
            </Button>
          </Form.Item>
        </Form>

        <div style={{ textAlign: 'center', marginTop: '1rem' }}>
          <Space>
            <span>已有账号?</span>
            <Link to="/login">
              立即登录
            </Link>
          </Space>
        </div>
      </Card>
    </div>
  );
};

export default Register;
