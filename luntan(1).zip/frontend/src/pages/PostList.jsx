import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, message, Pagination, Avatar, Space, Card } from 'antd';
import { EditOutlined, UserOutlined, ClockCircleOutlined, MessageOutlined } from '@ant-design/icons';
import { postAPI } from '../utils/api';

const PostList = ({ user, refreshTrigger, onShowCreatePost }) => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0
  });
  const navigate = useNavigate();

  useEffect(() => {
    fetchPosts();
  }, [pagination.current, refreshTrigger]);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const response = await postAPI.getPosts(pagination.current, pagination.pageSize);
      setPosts(response.posts);
      setPagination({
        ...pagination,
        total: response.total
      });
    } catch (error) {
      message.error('获取帖子列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handlePageChange = (page) => {
    setPagination({
      ...pagination,
      current: page
    });
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}天前`;

    return date.toLocaleDateString('zh-CN');
  };

  if (loading && posts.length === 0) {
    return (
      <div className="loading">
        <div>正在加载帖子...</div>
      </div>
    );
  }

  return (
    <div>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '2rem'
      }}>
        <h1>帖子列表</h1>
        {user && (
          <Button
            type="primary"
            icon={<EditOutlined />}
            size="large"
            id="create-post-btn"
            onClick={onShowCreatePost}
          >
            发布新帖子
          </Button>
        )}
      </div>

      {posts.length === 0 ? (
        <Card style={{ textAlign: 'center', padding: '3rem' }}>
          <h3>暂无帖子</h3>
          <p>成为第一个发布帖子的人吧！</p>
          {user && (
            <Button
              type="primary"
              onClick={onShowCreatePost}
              style={{ marginTop: '1rem' }}
            >
              发布帖子
            </Button>
          )}
        </Card>
      ) : (
        <>
          {posts.map(post => (
            <div
              key={post.id}
              className="post-card"
              onClick={() => navigate(`/post/${post.id}`)}
            >
              <div className="post-header">
                <div style={{ flex: 1 }}>
                  <h3 className="post-title">{post.title}</h3>
                  <p className="post-content">{post.content}</p>
                </div>
              </div>

              <div className="post-meta">
                <Space>
                  <div className="author-info">
                    <Avatar
                      size="small"
                      src={post.author.avatar}
                      icon={!post.author.avatar && <UserOutlined />}
                    />
                    <span>{post.author.username}</span>
                  </div>

                  <Space>
                    <ClockCircleOutlined />
                    <span>{formatDate(post.created_at)}</span>
                  </Space>

                  <Space>
                    <MessageOutlined />
                    <span>{post.comment_count} 条评论</span>
                  </Space>
                </Space>
              </div>
            </div>
          ))}

          <div style={{ textAlign: 'center', marginTop: '2rem' }}>
            <Pagination
              current={pagination.current}
              pageSize={pagination.pageSize}
              total={pagination.total}
              onChange={handlePageChange}
              showSizeChanger={false}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default PostList;
