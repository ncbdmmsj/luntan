import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button, Form, Input, message, Avatar, Space, Card } from 'antd';
import { UserOutlined, ClockCircleOutlined, ArrowLeftOutlined, SendOutlined } from '@ant-design/icons';
import { postAPI, commentAPI } from '../utils/api';

const { TextArea } = Input;

const PostDetail = ({ user }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [commentLoading, setCommentLoading] = useState(false);
  const [form] = Form.useForm();

  useEffect(() => {
    fetchPost();
  }, [id]);

  const fetchPost = async () => {
    setLoading(true);
    try {
      const postData = await postAPI.getPost(id);
      setPost(postData);
    } catch (error) {
      message.error('获取帖子详情失败');
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  const handleAddComment = async (values) => {
    if (!user) {
      message.warning('请先登录后再发表评论');
      return;
    }

    setCommentLoading(true);
    try {
      const commentData = {
        ...values,
        user_id: user.id
      };

      const response = await commentAPI.createComment(id, commentData);
      message.success('评论发布成功！');
      form.resetFields();
      // 将服务端返回的评论直接追加到本地状态，无感刷新且确保一致性
      if (response.comment) {
        setPost(prev => ({
          ...prev,
          comments: [...prev.comments, response.comment]
        }));
      }
    } catch (error) {
      message.error(error.error || '评论发布失败');
    } finally {
      setCommentLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="loading">
        <div>正在加载帖子...</div>
      </div>
    );
  }

  if (!post) {
    return (
      <Card style={{ textAlign: 'center', padding: '3rem' }}>
        <h3>帖子不存在</h3>
        <Button
          type="primary"
          onClick={() => navigate('/')}
          style={{ marginTop: '1rem' }}
        >
          返回帖子列表
        </Button>
      </Card>
    );
  }

  return (
    <div>
      <Button
        type="text"
        icon={<ArrowLeftOutlined />}
        onClick={() => navigate('/')}
        style={{ marginBottom: '1rem' }}
      >
        返回列表
      </Button>

      <Card style={{ marginBottom: '2rem' }}>
        <div style={{ marginBottom: '1rem' }}>
          <h1 style={{ fontSize: '1.8rem', marginBottom: '1rem', color: '#333' }}>
            {post.title}
          </h1>

          <Space style={{ marginBottom: '1rem', color: '#666' }}>
            <div className="author-info">
              <Avatar
                size="large"
                src={post.author.avatar}
                icon={!post.author.avatar && <UserOutlined />}
              />
              <span style={{ fontWeight: '500' }}>{post.author.username}</span>
            </div>

            <Space>
              <ClockCircleOutlined />
              <span>发布于 {formatDate(post.created_at)}</span>
            </Space>

            {post.updated_at !== post.created_at && (
              <Space>
                <span>（最后编辑于 {formatDate(post.updated_at)}）</span>
              </Space>
            )}
          </Space>
        </div>

        <div
          style={{
            fontSize: '1.1rem',
            lineHeight: '1.8',
            color: '#333',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word'
          }}
        >
          {post.content}
        </div>
      </Card>

      <div className="comment-section">
        <h3 style={{ marginBottom: '1rem' }}>
          评论 ({post.comments.length})
        </h3>

        {user ? (
          <Card style={{ marginBottom: '2rem' }}>
            <Form
              form={form}
              layout="vertical"
              onFinish={handleAddComment}
            >
              <Form.Item
                name="content"
                rules={[
                  { required: true, message: '请输入评论内容!' },
                  { min: 2, message: '评论至少2个字符!' },
                  { max: 1000, message: '评论不能超过1000个字符!' }
                ]}
              >
                <TextArea
                  placeholder="写下你的评论..."
                  rows={3}
                  showCount
                  maxLength={1000}
                />
              </Form.Item>

              <Form.Item style={{ marginBottom: 0, textAlign: 'right' }}>
                <Button
                  type="primary"
                  htmlType="submit"
                  loading={commentLoading}
                  icon={<SendOutlined />}
                >
                  发表评论
                </Button>
              </Form.Item>
            </Form>
          </Card>
        ) : (
          <Card style={{ textAlign: 'center', marginBottom: '2rem' }}>
            <p>请先登录后再发表评论</p>
            <Space>
              <Button type="primary" onClick={() => navigate('/login')}>
                登录
              </Button>
              <Button onClick={() => navigate('/register')}>
                注册
              </Button>
            </Space>
          </Card>
        )}

        {post.comments.length === 0 ? (
          <Card style={{ textAlign: 'center', padding: '2rem' }}>
            <p>暂无评论，成为第一个评论的人吧！</p>
          </Card>
        ) : (
          <div>
            {post.comments.map(comment => (
              <div key={comment.id} className="comment">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
                  <Space>
                    <Avatar
                      size="small"
                      src={comment.author.avatar}
                      icon={!comment.author.avatar && <UserOutlined />}
                    />
                    <span style={{ fontWeight: '500' }}>{comment.author.username}</span>
                  </Space>

                  <span style={{ color: '#999', fontSize: '0.9rem' }}>
                    {formatDate(comment.created_at)}
                  </span>
                </div>

                <div style={{
                  color: '#333',
                  lineHeight: '1.6',
                  whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word'
                }}>
                  {comment.content}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PostDetail;
