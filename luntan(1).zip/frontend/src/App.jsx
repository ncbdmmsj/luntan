import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { message } from 'antd';
import Header from './components/Header';
import CreatePostModal from './components/CreatePostModal';
import Login from './pages/Login';
import Register from './pages/Register';
import PostList from './pages/PostList';
import PostDetail from './pages/PostDetail';
import { initAPI } from './utils/api';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [createPostVisible, setCreatePostVisible] = useState(false);
  const [postRefreshTrigger, setPostRefreshTrigger] = useState(0);

  useEffect(() => {
    const initDatabase = async () => {
      try {
        await initAPI.initDatabase();
        console.log('数据库初始化成功');
      } catch (error) {
        console.log('数据库已存在或初始化失败:', error);
      } finally {
        setLoading(false);
      }
    };

    initDatabase();

    const savedUser = localStorage.getItem('forumUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (userData) => {
    setUser(userData);
    localStorage.setItem('forumUser', JSON.stringify(userData));
    message.success('登录成功！');
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('forumUser');
    message.success('已退出登录');
  };

  const handlePostCreated = () => {
    setPostRefreshTrigger(prev => prev + 1);
  };

  if (loading) {
    return (
      <div className="loading">
        <div>正在初始化系统...</div>
      </div>
    );
  }

  return (
    <Router>
      <div className="App">
        <Header
          user={user}
          onLogout={handleLogout}
          onShowCreatePost={() => setCreatePostVisible(true)}
        />

        <main className="main-content">
          <div className="container">
            <Routes>
              <Route path="/" element={
                <PostList
                  user={user}
                  refreshTrigger={postRefreshTrigger}
                  onShowCreatePost={() => setCreatePostVisible(true)}
                />
              } />
              <Route
                path="/login"
                element={
                  user ? <Navigate to="/" replace /> : <Login onLogin={handleLogin} />
                }
              />
              <Route
                path="/register"
                element={
                  user ? <Navigate to="/" replace /> : <Register />
                }
              />
              <Route path="/post/:id" element={<PostDetail user={user} />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </main>

        <CreatePostModal
          visible={createPostVisible}
          onCancel={() => setCreatePostVisible(false)}
          onSuccess={handlePostCreated}
          user={user}
        />
      </div>
    </Router>
  );
}

export default App;
