import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 请求拦截器
api.interceptors.request.use(
  (config) => {
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 响应拦截器
api.interceptors.response.use(
  (response) => {
    return response.data;
  },
  (error) => {
    if (error.response) {
      return Promise.reject(error.response.data);
    } else if (error.request) {
      return Promise.reject({ error: '网络错误，请检查网络连接' });
    } else {
      return Promise.reject({ error: '请求配置错误' });
    }
  }
);

export const authAPI = {
  register: (userData) => api.post('/register', userData),
  login: (credentials) => api.post('/login', credentials),
};

export const postAPI = {
  getPosts: (page = 1, perPage = 10) => api.get(`/posts?page=${page}&per_page=${perPage}`),
  getPost: (postId) => api.get(`/posts/${postId}`),
  createPost: (postData) => api.post('/posts', postData),
};

export const commentAPI = {
  createComment: (postId, commentData) => api.post(`/posts/${postId}/comments`, commentData),
};

export const initAPI = {
  initDatabase: () => api.post('/init'),
};

export default api;