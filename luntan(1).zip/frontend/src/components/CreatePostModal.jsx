import React from 'react';
import { Modal, Form, Input, Button, Space, message } from 'antd';
import { postAPI } from '../utils/api';

const { TextArea } = Input;

const CreatePostModal = ({ visible, onCancel, onSuccess, user }) => {
  const [form] = Form.useForm();

  const handleCancel = () => {
    form.resetFields();
    onCancel();
  };

  const handleCreatePost = async (values) => {
    try {
      const postData = {
        ...values,
        user_id: user?.id || 1
      };

      await postAPI.createPost(postData);
      message.success('帖子发布成功！');
      form.resetFields();
      onCancel();
      onSuccess();
    } catch (error) {
      message.error(error.error || '发布失败，请重试');
    }
  };

  return (
    <Modal
      title="发布新帖子"
      open={visible}
      onCancel={handleCancel}
      footer={null}
      width={600}
    >
      <Form
        form={form}
        layout="vertical"
        onFinish={handleCreatePost}
      >
        <Form.Item
          label="标题"
          name="title"
          rules={[
            { required: true, message: '请输入帖子标题!' },
            { min: 5, message: '标题至少5个字符!' },
            { max: 200, message: '标题不能超过200个字符!' }
          ]}
        >
          <Input placeholder="请输入帖子标题" size="large" />
        </Form.Item>

        <Form.Item
          label="内容"
          name="content"
          rules={[
            { required: true, message: '请输入帖子内容!' },
            { min: 10, message: '内容至少10个字符!' }
          ]}
        >
          <TextArea
            placeholder="请输入帖子内容"
            rows={6}
            showCount
            maxLength={5000}
          />
        </Form.Item>

        <Form.Item>
          <Space>
            <Button
              type="primary"
              htmlType="submit"
            >
              发布
            </Button>
            <Button onClick={handleCancel}>
              取消
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default CreatePostModal;
