import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button, Avatar, Space } from 'antd';
import { UserOutlined, LoginOutlined, UserAddOutlined, EditOutlined } from '@ant-design/icons';

const Header = ({ user, onLogout, onShowCreatePost }) => {
  const location = useLocation();

  return (
    <header className="header">
      <div className="container">
        <div className="header-content">
          <Link to="/" className="logo">
            💬 论坛系统
          </Link>
          
          <nav className="nav-links">
            {user ? (
              <Space>
                <Link to="/" className="nav-link">
                  帖子列表
                </Link>
                <span 
                  className="nav-link" 
                  onClick={onShowCreatePost}
                  style={{ cursor: 'pointer' }}
                >
                  <EditOutlined /> 发布帖子
                </span>
                <Space>
                  <Avatar 
                    size="small" 
                    src={user.avatar} 
                    icon={!user.avatar && <UserOutlined />}
                  />
                  <span>{user.username}</span>
                </Space>
                <Button type="text" onClick={onLogout} style={{ color: 'white' }}>
                  <LoginOutlined /> 退出
                </Button>
              </Space>
            ) : (
              <Space>
                <Link to="/" className="nav-link">
                  帖子列表
                </Link>
                <Link 
                  to="/login" 
                  className="nav-link"
                  state={{ from: location.pathname }}
                >
                  <LoginOutlined /> 登录
                </Link>
                <Link 
                  to="/register" 
                  className="nav-link"
                  state={{ from: location.pathname }}
                >
                  <UserAddOutlined /> 注册
                </Link>
              </Space>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;